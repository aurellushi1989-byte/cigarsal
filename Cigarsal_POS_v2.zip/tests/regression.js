// Përdorimi:  node regression.js ../index.html [backup.json] [--init]
// Pa backup.json: vetëm skenarët. Me backup.json: auditim + totale; --init ruan totalet "e arta" (backup.json.golden.json), pa --init i krahason.
const fs=require("fs");const A=process.argv.slice(2),init=A.includes("--init"),[htmlP,dataP]=A.filter(x=>!x.startsWith("--"));
if(!htmlP){console.log("Përdorimi: node regression.js ../index.html [backup.json] [--init]");process.exit(2)}
const html=fs.readFileSync(htmlP,"utf8"),src=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).sort((a,b)=>b.length-a.length)[0];
const fn=n=>{const i=src.indexOf("function "+n+"(");if(i<0)throw Error("mungon "+n);let d=0;for(let k=src.indexOf("{",i);k<src.length;k++){if(src[k]=="{")d++;else if(src[k]=="}"&&!--d)return src.slice(i,k+1)}};
const cn=n=>{const m=src.match(new RegExp("^const "+n+"=[^\\n]*","m"));if(!m)throw Error("mungon "+n);return m[0]};
const code=`var db,SF="";var uid=()=>Math.random().toString(36).slice(2)+Date.now().toString(36);var L=n=>Math.round(n)+" L";
${["cogs","inR","validDb","norm"].map(cn).join(";\n")};
${["sell","receive","retDo","payDo","revCost","stats","auditDb"].map(fn).join("\n")}
return{sell,receive,retDo,payDo,revCost,stats,auditDb,cogs,validDb,norm,setDb:d=>{db=d}}`;
const E=new Function(code)();let fail=0;const ok=(n,c)=>{console.log((c?"✔ ":"✘ ")+n);if(!c)fail++};const bad=f=>{try{f();return false}catch(e){return true}};
const mk=()=>({prods:[{id:"a",name:"T",qty:0,cost:0,price:100,min:0,active:true}],sales:[],purchases:[],expenses:[],moves:[],cats:[],log:[],seq:0,returns:[],rseq:0,tax:{vat:0,ptax:0}});
// --- skenarë
{const D=mk();E.setDb(D);const p=E.receive({lines:[{pid:"a",qty:10,cost:50}],disc:0,transport:0,paid:0},D);D.purchases.push(Object.assign(p,{status:"ok",supplier:"S",no:"1"}));
 const p2=E.receive({lines:[{pid:"a",qty:10,cost:70}],disc:0,transport:0,paid:0},D);D.purchases.push(Object.assign(p2,{status:"ok",supplier:"S",no:"2",t:1}));
 ok("Kosto mesatare e ponderuar 60",D.prods[0].cost===60);
 ok("Pagesa e furnitorit zvogëlon borxhin",E.payDo(D,p2,300,"Cash").due===400&&p2.paid===300);ok("Pagesa mbi borxhin refuzohet",bad(()=>E.payDo(D,p2,401,"Cash")));
 const pr=D.prods[0];E.revCost(pr,p2.lines[0]);pr.qty-=10;ok("Anulimi i furnizimit rikthen koston 50",Math.abs(pr.cost-50)<1e-9&&pr.qty===10);
 const s=E.sell([{pid:"a",qty:4}],{disc:40,cash:100,card:200,online:60},D);ok("Pagesa e kombinuar = total 360",s.total===360);
 const r=E.retDo(D,s,{a:2},"card","t");ok("Kthim 2 copë: 180 L, stok +2",r.amount===180&&pr.qty===8);ok("Kthimi mbi pagesën e kartës refuzohet",bad(()=>E.retDo(D,s,{a:2},"card","t")));
 D.tax={vat:20,ptax:10};const st=E.stats([0,9e15]);ok("Rev neto kthimeve 180",st.rev===180);ok("Fitimi neto përfshin TVSH/tatim",Math.abs(st.net-(st.gp-st.ex-Math.max(0,st.gp-st.ex)*0.1))<1e-9);
 const AE=E.auditDb(D).filter(x=>x.l==="e");AE.forEach(x=>console.log("   "+x.m));ok("Audit pa gabime",AE.length===0);}
// --- të dhëna reale
if(dataP){let d=JSON.parse(fs.readFileSync(dataP,"utf8"));if(d.__cigars)d=JSON.parse(d.data);E.norm(d);ok("Struktura e vlefshme",E.validDb(d));E.setDb(d);
 const I=E.auditDb(d),M={counts:{prods:d.prods.length,sales:d.sales.length,returns:d.returns.length,purchases:d.purchases.length,expenses:d.expenses.length},auditErrors:I.filter(x=>x.l==="e").length,
  stockValue:Math.round(d.prods.reduce((a,p)=>a+Math.max(p.qty,0)*p.cost,0)),debts:{},months:{}};
 d.purchases.filter(x=>x.status==="ok").forEach(x=>M.debts[x.supplier]=Math.round((M.debts[x.supplier]||0)+x.due));
 const ms=new Set([...d.sales,...d.returns].map(x=>{const t=new Date(x.t);return t.getFullYear()+"-"+t.getMonth()}));
 ms.forEach(k=>{const[y,m]=k.split("-").map(Number),s=E.stats([new Date(y,m,1).getTime(),new Date(y,m+1,1).getTime()]);M.months[y+"-"+String(m+1).padStart(2,"0")]={n:s.n,rev:Math.round(s.rev),cg:Math.round(s.cg),ex:Math.round(s.ex),net:Math.round(s.net),cash:Math.round(s.cash),card:Math.round(s.card),online:Math.round(s.online)}});
 ok("Audit i të dhënave reale pa gabime ("+M.auditErrors+")",M.auditErrors===0);
 const g=dataP+".golden.json";if(init||!fs.existsSync(g)){fs.writeFileSync(g,JSON.stringify(M,null,1));console.log("• Totalet e arta u ruajtën: "+g)}
 else{const G=JSON.parse(fs.readFileSync(g,"utf8")),fl=(o,p="")=>Object.entries(o).flatMap(([k,v])=>typeof v==="object"?fl(v,p+k+"."):[[p+k,v]]),a=Object.fromEntries(fl(G)),b=Object.fromEntries(fl(M));
  const diff=[...new Set([...Object.keys(a),...Object.keys(b)])].filter(k=>a[k]!==b[k]);diff.forEach(k=>console.log("✘ ndryshim: "+k+"  "+a[k]+" → "+b[k]));ok("Totalet përputhen me të arta ("+diff.length+" dallime)",!diff.length)}}
console.log(fail?"\n"+fail+" TESTE DËSHTUAN":"\nTË GJITHA TESTET KALUAN");process.exit(fail?1:0)
